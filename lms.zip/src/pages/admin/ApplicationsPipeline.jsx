import React, { useState } from 'react';
import { 
  FileText, 
  Search, 
  Filter, 
  MoreHorizontal, 
  ArrowRight,
  Clock,
  CheckCircle2,
  AlertCircle,
  Download,
  Eye,
  Settings
} from 'lucide-react';
import { useLoans, STATUSES } from '../../context/LoanContext';
import { SectionHeader, Badge, StatCard } from '../../components/ui/Shared';

const ApplicationsPipeline = () => {
    const { applications, updateStatus } = useLoans();
    const [searchTerm, setSearchTerm] = useState('');

    const filteredApps = applications.filter(app => 
        app.name.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.id.toLowerCase().includes(searchTerm.toLowerCase()) ||
        app.status.toLowerCase().includes(searchTerm.toLowerCase())
    );

    const getStatusVariant = (status) => {
        switch(status) {
            case STATUSES.ADMIN_APPROVED:
            case STATUSES.DISBURSED: return 'success';
            case STATUSES.HR_PENDING:
            case STATUSES.CREDIT_PENDING:
            case STATUSES.ADMIN_PENDING: return 'warning';
            case STATUSES.DECLINED:
            case STATUSES.HR_REJECTED: return 'danger';
            default: return 'primary';
        }
    };

    const handleFinalApprove = (id) => {
        updateStatus(id, STATUSES.ADMIN_APPROVED);
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <SectionHeader 
                title="Application Pipeline" 
                description="Monitor and manage all loan applications through their full lifecycle."
            />

            <div className="glass p-8 rounded-[40px] space-y-8">
                <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
                    <div className="flex items-center gap-4 bg-slate-950 p-2 rounded-2xl border border-slate-800 w-full max-w-md">
                        <Search className="w-5 h-5 text-slate-500 ml-2" />
                        <input 
                            className="bg-transparent border-none text-sm focus:ring-0 w-full text-slate-200" 
                            placeholder="Search by name, ID or status..." 
                            value={searchTerm}
                            onChange={(e) => setSearchTerm(e.target.value)}
                        />
                    </div>
                    <div className="flex gap-3">
                        <button className="flex items-center gap-2 px-5 py-2.5 glass rounded-xl text-sm font-bold text-slate-300 hover:text-white transition-all">
                            <Filter className="w-4 h-4" />
                            Filters
                        </button>
                        <button className="flex items-center gap-2 px-5 py-2.5 bg-blue-600 rounded-xl text-sm font-bold text-white hover:bg-blue-500 transition-all shadow-lg shadow-blue-600/20">
                            <Download className="w-4 h-4" />
                            Export CSV
                        </button>
                    </div>
                </div>

                <div className="overflow-x-auto">
                    <table className="w-full text-left">
                        <thead>
                            <tr className="bg-slate-900/50 border-b border-slate-800/50">
                                <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Applicant</th>
                                <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">Amount</th>
                                <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">Status</th>
                                <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Last Activity</th>
                                <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                            </tr>
                        </thead>
                        <tbody className="divide-y divide-slate-800/50">
                            {filteredApps.map((app) => (
                                <tr key={app.id} className="hover:bg-slate-800/30 transition-colors group">
                                    <td className="px-8 py-6">
                                        <div className="flex items-center gap-4">
                                            <div className="w-10 h-10 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs text-blue-400">
                                                {app.name[0]}
                                            </div>
                                            <div>
                                                <p className="font-bold text-slate-200">{app.name}</p>
                                                <p className="text-xs text-slate-500">{app.email}</p>
                                            </div>
                                        </div>
                                    </td>
                                    <td className="px-8 py-6 text-center">
                                        <p className="font-bold text-slate-200">R {app.amount?.toLocaleString()}</p>
                                        <p className="text-[10px] text-slate-500 uppercase tracking-tighter">Term: 3 Months</p>
                                    </td>
                                    <td className="px-8 py-6 text-center">
                                        <Badge variant={getStatusVariant(app.status)}>{app.status}</Badge>
                                    </td>
                                    <td className="px-8 py-6">
                                        <div className="flex items-center gap-2 text-sm text-slate-400">
                                            <Clock className="w-4 h-4 text-slate-600" />
                                            {new Date(app.date).toLocaleDateString()}
                                        </div>
                                    </td>
                                    <td className="px-8 py-6 text-right">
                                        <div className="flex justify-end gap-2">
                                            {app.status === STATUSES.ADMIN_PENDING && (
                                                <button 
                                                    onClick={() => handleFinalApprove(app.id)}
                                                    className="px-4 py-1.5 rounded-lg bg-emerald-600 text-white text-xs font-bold hover:bg-emerald-500 transition-all"
                                                >
                                                    Approve
                                                </button>
                                            )}
                                            <button className="p-2 text-slate-500 hover:text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all">
                                                <Eye className="w-4 h-4" />
                                            </button>
                                            <button className="p-2 text-slate-500 hover:text-slate-300 rounded-lg transition-all">
                                                <MoreHorizontal className="w-4 h-4" />
                                            </button>
                                        </div>
                                    </td>
                                </tr>
                            ))}
                            {filteredApps.length === 0 && (
                                <tr>
                                    <td colSpan={5} className="px-8 py-20 text-center text-slate-500">
                                        No applications found matching your search criteria.
                                    </td>
                                </tr>
                            )}
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    );
};

export default ApplicationsPipeline;
