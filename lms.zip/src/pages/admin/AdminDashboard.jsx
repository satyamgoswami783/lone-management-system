import React from 'react';
import { 
  Users, 
  FileText, 
  Clock, 
  CheckCircle2, 
  Search,
  Filter,
  MoreHorizontal,
  ChevronRight,
  BarChart3,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { StatCard, SectionHeader, Badge } from '../../components/ui/Shared';

const AdminDashboard = () => {
    const stats = [
        { title: 'Total Applications', value: '1,284', icon: FileText, variant: 'primary', trend: { type: 'up', value: 12 } },
        { title: 'Pending HR', value: '42', icon: Clock, variant: 'warning', trend: { type: 'down', value: 5 } },
        { title: 'Approved Today', value: '18', icon: CheckCircle2, variant: 'success', trend: { type: 'up', value: 8 } },
        { title: 'Requires Review', value: '7', icon: AlertCircle, variant: 'danger', trend: { type: 'up', value: 2 } },
    ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <SectionHeader 
        title="Operations Overview" 
        description="Monitor and manage all loan applications across the pipeline."
      />

      {/* Stats Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {stats.map((stat, i) => (
            <StatCard key={i} {...stat} />
        ))}
      </div>

      <div className="grid grid-cols-1 xl:grid-cols-3 gap-8">
        {/* Applications List */}
        <div className="xl:col-span-2 space-y-4">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4 px-2">
            <h2 className="text-xl font-display font-bold">Recent Applications</h2>
            <div className="flex items-center gap-2">
                <div className="relative">
                    <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                    <input className="input-field pl-9 py-1.5 text-sm w-48 md:w-64" placeholder="Search applicant..." />
                </div>
                <button className="p-2 glass rounded-xl text-slate-400 hover:text-white transition-colors">
                    <Filter className="w-4 h-4" />
                </button>
            </div>
          </div>
          
          <div className="glass rounded-3xl overflow-hidden border border-slate-800/50">
            <table className="w-full text-left">
              <thead>
                <tr className="bg-slate-900/50 border-b border-slate-800/50">
                  <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Applicant</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Company</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Amount</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Stage</th>
                  <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Action</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/50">
                {[
                  { name: 'Sarah Jenkins', email: 'sarah.j@gmail.com', company: 'TechFlow SA', amount: 'R 5,000', stage: 'HR Pending', sVar: 'warning' },
                  { name: 'Michael Chen', email: 'm.chen@outlook.com', company: 'Global Logistics', amount: 'R 3,500', stage: 'Credit Review', sVar: 'primary' },
                  { name: 'David Smith', email: 'david.s@comp.co', company: 'Standard Bank', amount: 'R 9,000', stage: 'Approved', sVar: 'success' },
                  { name: 'Lerato Molefe', email: 'lerato@web.za', company: 'Vodacom Group', amount: 'R 2,400', stage: 'Finance Final', sVar: 'primary' },
                  { name: 'Emma Wilson', email: 'emma@home.com', company: 'Woolworths', amount: 'R 1,500', stage: 'HR Rejected', sVar: 'danger' },
                ].map((row, i) => (
                  <tr key={i} className="hover:bg-slate-800/30 transition-colors group">
                    <td className="px-6 py-4">
                        <div className="flex items-center gap-3">
                            <div className="w-8 h-8 rounded-full bg-slate-800 flex items-center justify-center font-bold text-xs text-blue-400">
                                {row.name[0]}
                            </div>
                            <div>
                                <p className="font-medium text-slate-200">{row.name}</p>
                                <p className="text-xs text-slate-500">{row.email}</p>
                            </div>
                        </div>
                    </td>
                    <td className="px-6 py-4 text-sm text-slate-400">{row.company}</td>
                    <td className="px-6 py-4 text-sm font-semibold text-slate-200">{row.amount}</td>
                    <td className="px-6 py-4">
                      <Badge variant={row.sVar}>{row.stage}</Badge>
                    </td>
                    <td className="px-6 py-4 text-right">
                        <button className="p-2 text-slate-500 hover:text-blue-400 hover:bg-blue-400/10 rounded-lg transition-all group-hover:scale-110">
                            <MoreHorizontal className="w-5 h-5" />
                        </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
            <div className="bg-slate-900/50 px-6 py-4 flex items-center justify-between border-t border-slate-800/50">
                <span className="text-sm text-slate-500">Showing page 1 of 25</span>
                <div className="flex gap-2">
                    <button className="px-3 py-1 glass rounded-lg text-xs font-bold text-slate-500 cursor-not-allowed">Prev</button>
                    <button className="px-3 py-1 glass rounded-lg text-xs font-bold text-slate-300 hover:bg-slate-800 transition-colors">Next</button>
                </div>
            </div>
          </div>
        </div>

        {/* Sidebar Analytics */}
        <div className="space-y-6">
            <h2 className="text-xl font-display font-bold px-2">Pipeline Summary</h2>
            <div className="glass p-6 rounded-[32px] space-y-8 relative overflow-hidden">
                {/* Decoration */}
                <div className="absolute top-0 right-0 w-32 h-32 bg-blue-600/5 rounded-full blur-3xl"></div>

                <div className="space-y-4">
                    <div className="flex items-center justify-between text-sm">
                        <span className="text-slate-400">Approval Rate</span>
                        <span className="text-emerald-400 font-bold">78%</span>
                    </div>
                    <div className="w-full h-1.5 bg-slate-800 rounded-full overflow-hidden">
                        <div className="h-full bg-emerald-500 rounded-full" style={{ width: '78%' }}></div>
                    </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 bg-slate-900/50 rounded-2xl border border-slate-800/50">
                        <TrendingUp className="w-5 h-5 text-blue-400 mb-2" />
                        <p className="text-xs text-slate-500 uppercase tracking-wider font-bold">Growth</p>
                        <p className="text-xl font-display font-bold">+24%</p>
                    </div>
                    <div className="p-4 bg-slate-900/50 rounded-2xl border border-slate-800/50">
                        <BarChart3 className="w-5 h-5 text-purple-400 mb-2" />
                        <p className="text-xs text-slate-500 uppercase tracking-wider font-bold">Target</p>
                        <p className="text-xl font-display font-bold">92%</p>
                    </div>
                </div>

                <div className="space-y-4 pt-4 border-t border-slate-800/50">
                    <h3 className="text-sm font-bold text-slate-400 uppercase tracking-widest">Active Alerts</h3>
                    <div className="flex items-start gap-4 p-4 rounded-2xl bg-red-400/5 border border-red-500/10">
                        <AlertCircle className="w-5 h-5 text-red-400 shrink-0" />
                        <div>
                            <p className="text-sm font-medium text-red-200">System Latency</p>
                            <p className="text-xs text-slate-500 mt-1">Deduction file matching is slower than usual.</p>
                        </div>
                    </div>
                </div>

                <button className="w-full py-4 rounded-2xl bg-blue-600 text-white font-bold text-sm hover:bg-blue-500 transition-all flex items-center justify-center gap-2 group shadow-lg shadow-blue-500/20 active:scale-95">
                    View Full Reports
                    <ChevronRight className="w-4 h-4 group-hover:translate-x-1 transition-transform" />
                </button>
            </div>
        </div>
      </div>
    </div>
  );
};

export default AdminDashboard;
