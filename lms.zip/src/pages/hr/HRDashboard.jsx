import React from 'react';
import { 
  Users, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search,
  Filter,
  Eye,
  FileText
} from 'lucide-react';
import { StatCard, SectionHeader, Badge } from '../../components/ui/Shared';

const HRDashboard = () => {
    const stats = [
        { title: 'To Verify', value: '12', icon: Clock, variant: 'warning' },
        { title: 'Verified This Week', value: '84', icon: CheckCircle2, variant: 'success' },
        { title: 'Rejections', value: '3', icon: XCircle, variant: 'danger' },
    ];

  return (
    <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
      <SectionHeader 
        title="Employee Verification" 
        description="Verify employment and salary details for loan applicants."
      />

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        {stats.map((stat, i) => (
            <StatCard key={i} {...stat} />
        ))}
      </div>

      <div className="glass rounded-[32px] overflow-hidden border border-slate-800/50">
        <div className="p-6 border-b border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <h2 className="text-xl font-display font-bold">Verification Queue</h2>
            <div className="flex gap-2">
                <input className="input-field py-1.5 text-sm w-64" placeholder="Search employee..." />
                <button className="p-2 glass rounded-xl text-slate-400 hover:text-white transition-colors">
                    <Filter className="w-4 h-4" />
                </button>
            </div>
        </div>
        <table className="w-full text-left">
          <thead>
            <tr className="bg-slate-900/50 border-b border-slate-800/50">
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Employee</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Employee ID</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Salary</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Submitted</th>
              <th className="px-6 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-800/50">
            {[
              { name: 'Sarah Jenkins', id: 'EMP-9021', salary: 'R 22,500', date: '2 hours ago' },
              { name: 'Michael Chen', id: 'EMP-8842', salary: 'R 18,000', date: '5 hours ago' },
              { name: 'Lerato Molefe', id: 'EMP-1029', salary: 'R 24,000', date: '1 day ago' },
            ].map((row, i) => (
              <tr key={i} className="hover:bg-slate-800/30 transition-colors group">
                <td className="px-6 py-4 font-medium text-slate-200">{row.name}</td>
                <td className="px-6 py-4 text-sm text-slate-400">{row.id}</td>
                <td className="px-6 py-4 text-sm font-semibold text-slate-200">{row.salary}</td>
                <td className="px-6 py-4 text-sm text-slate-500">{row.date}</td>
                <td className="px-6 py-4 text-right">
                    <div className="flex justify-end gap-2">
                        <button className="px-3 py-1.5 rounded-lg bg-emerald-600/10 text-emerald-400 text-xs font-bold hover:bg-emerald-600 hover:text-white transition-all">Verify</button>
                        <button className="px-3 py-1.5 rounded-lg bg-red-600/10 text-red-400 text-xs font-bold hover:bg-red-600 hover:text-white transition-all">Reject</button>
                        <button className="p-1.5 text-slate-500 hover:text-blue-400 rounded-lg transition-colors"><Eye className="w-4 h-4" /></button>
                    </div>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
};

export default HRDashboard;
