import React from 'react';
import { 
  Users, 
  CheckCircle2, 
  XCircle, 
  Clock, 
  Search,
  Filter,
  Eye,
  FileText,
  Briefcase,
  TrendingUp,
  AlertCircle
} from 'lucide-react';
import { useLoans, STATUSES } from '../../context/LoanContext';
import { StatCard, SectionHeader, Badge } from '../../components/ui/Shared';

const VerificationQueue = () => {
    const { applications, updateStatus } = useLoans();
    
    // Only show "Submitted" applications in the verification queue
    const queue = applications.filter(app => app.status === STATUSES.HR_PENDING || app.status === STATUSES.SUBMITTED);
    
    const stats = [
        { title: 'Pending Verification', value: queue.length.toString(), icon: Clock, variant: 'warning' },
        { title: 'Approved This Week', value: '124', icon: CheckCircle2, variant: 'success' },
        { title: 'Rejected', value: '8', icon: XCircle, variant: 'danger' },
    ];

    const handleVerify = (id) => {
        updateStatus(id, STATUSES.HR_APPROVED);
        // In a real app, we'd then move it to CREDIT_PENDING automatically or via logic
        setTimeout(() => updateStatus(id, STATUSES.CREDIT_PENDING), 500);
    };

    const handleReject = (id) => {
        updateStatus(id, STATUSES.HR_REJECTED);
    };

    return (
        <div className="space-y-8 animate-in fade-in slide-in-from-bottom-4 duration-700">
            <SectionHeader 
                title="Employee Verification Queue" 
                description="Review and verify applicant employment details to proceed with the loan process."
            />

            <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                {stats.map((stat, i) => (
                    <StatCard key={i} {...stat} />
                ))}
            </div>

            <div className="glass rounded-[32px] overflow-hidden border border-slate-800/50">
                <div className="p-6 border-b border-slate-800/50 flex flex-col sm:flex-row sm:items-center justify-between gap-4 bg-slate-900/20">
                    <h2 className="text-xl font-display font-bold text-slate-200">Pending Approvals</h2>
                    <div className="flex gap-2">
                        <div className="relative">
                            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-500" />
                            <input className="input-field pl-9 py-1.5 text-sm w-64" placeholder="Search employee..." />
                        </div>
                        <button className="p-2 glass rounded-xl text-slate-400 hover:text-white transition-colors">
                            <Filter className="w-4 h-4" />
                        </button>
                    </div>
                </div>

                {queue.length === 0 ? (
                    <div className="p-20 text-center flex flex-col items-center justify-center space-y-4">
                        <div className="w-16 h-16 rounded-full bg-slate-900 flex items-center justify-center text-slate-700">
                            <CheckCircle2 className="w-10 h-10" />
                        </div>
                        <h3 className="text-xl font-display font-bold text-slate-500">Queue Clear!</h3>
                        <p className="text-slate-600">No pending verifications at this time.</p>
                    </div>
                ) : (
                    <div className="overflow-x-auto">
                        <table className="w-full text-left">
                            <thead>
                                <tr className="bg-slate-900/50 border-b border-slate-800/50">
                                    <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-center">Applicant</th>
                                    <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Details</th>
                                    <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider">Salary</th>
                                    <th className="px-8 py-4 text-xs font-semibold text-slate-500 uppercase tracking-wider text-right">Actions</th>
                                </tr>
                            </thead>
                            <tbody className="divide-y divide-slate-800/50">
                                {queue.map((app) => (
                                    <tr key={app.id} className="hover:bg-slate-800/30 transition-colors group">
                                        <td className="px-8 py-6">
                                            <div className="flex items-center gap-4">
                                                <div className="w-10 h-10 rounded-full bg-blue-600/10 flex items-center justify-center font-bold text-blue-400">
                                                    {app.name[0]}
                                                </div>
                                                <div>
                                                    <p className="font-bold text-slate-200">{app.name}</p>
                                                    <p className="text-xs text-slate-500 uppercase tracking-widest">{app.id}</p>
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6">
                                            <div className="space-y-1">
                                                <div className="flex items-center gap-2 text-sm text-slate-300">
                                                    <Briefcase className="w-3.5 h-3.5 text-slate-500" />
                                                    {app.company}
                                                </div>
                                                <div className="flex items-center gap-2 text-xs text-slate-500">
                                                    <Clock className="w-3.5 h-3.5" />
                                                    Applied {new Date(app.date).toLocaleDateString()}
                                                </div>
                                            </div>
                                        </td>
                                        <td className="px-8 py-6 text-sm font-semibold text-slate-200">
                                            R {app.salary?.toLocaleString() || 'N/A'}
                                        </td>
                                        <td className="px-8 py-6 text-right">
                                            <div className="flex justify-end gap-3">
                                                <button 
                                                    onClick={() => handleVerify(app.id)}
                                                    className="px-4 py-2 rounded-xl bg-emerald-600/10 text-emerald-400 text-xs font-bold hover:bg-emerald-600 hover:text-white transition-all shadow-lg shadow-emerald-600/5"
                                                >
                                                    Verify Info
                                                </button>
                                                <button 
                                                    onClick={() => handleReject(app.id)}
                                                    className="px-4 py-2 rounded-xl bg-red-600/10 text-red-400 text-xs font-bold hover:bg-red-600 hover:text-white transition-all"
                                                >
                                                    Reject
                                                </button>
                                                <button className="p-2 text-slate-500 hover:text-blue-400 hover:bg-blue-400/10 rounded-xl transition-all">
                                                    <Eye className="w-5 h-5" />
                                                </button>
                                            </div>
                                        </td>
                                    </tr>
                                ))}
                            </tbody>
                        </table>
                    </div>
                )}
            </div>
        </div>
    );
};

export default VerificationQueue;
